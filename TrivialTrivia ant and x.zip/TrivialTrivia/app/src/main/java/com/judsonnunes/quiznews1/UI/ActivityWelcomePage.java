package com.judsonnunes.quiznews1.UI;

import android.annotation.TargetApi;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.transition.Fade;
import android.transition.TransitionInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.github.ybq.android.spinkit.SpinKitView;
import com.judsonnunes.quiznews1.NewsBlogger.BloggerAPI;
import com.judsonnunes.quiznews1.NewsBlogger.Item;
import com.judsonnunes.quiznews1.NewsBlogger.MainActivityBlog;
import com.judsonnunes.quiznews1.NewsBlogger.PostAdapter;
import com.judsonnunes.quiznews1.NewsBlogger.PostList;
import com.judsonnunes.quiznews1.R;
import com.judsonnunes.quiznews1.data.QuizDBContract;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
public class ActivityWelcomePage extends AppCompatActivity {

    /**
     *
     */
    RecyclerView recyclerView;
    LinearLayoutManager manager;
    PostAdapter adapter;
    List<Item> items = new ArrayList<>();
    Boolean isScrolling = false;
    int currentItems, totalItems, scrollOutItems;
    String token = "";
    SpinKitView progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_page);
        recyclerView = findViewById(R.id.postList);
        manager = new LinearLayoutManager(this);
        adapter = new PostAdapter(this, items);
        recyclerView.setLayoutManager(manager);
        recyclerView.setAdapter(adapter);
        progress = findViewById(R.id.spin_kit);

        if (Build.VERSION.SDK_INT >= 21) {
            setupWindowAnimations();
        }


       // ImageView imageView = (ImageView) findViewById(R.id.imageview_welcome_page);
        //imageView.getLayoutParams().height = 300;
       // imageView.getLayoutParams().width = 300;

        ((ImageView) findViewById(R.id.imageview_start)).setImageDrawable(getRoundedDrawable("start.jpg"));
        ((ImageView) findViewById(R.id.imageview_statistics)).setImageDrawable(getRoundedDrawable("statistics.jpg"));
        ((ImageView) findViewById(R.id.imageview_instructions)).setImageDrawable(getRoundedDrawable("instructions.png"));
        ((ImageView) findViewById(R.id.imageview_acknowledgments)).setImageDrawable(getRoundedDrawable("acknowledgements.jpg"));

        CardView startCardview = (CardView) findViewById(R.id.card_view_start_game);
        startCardview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityWelcomePage.this, ActivityQuiz.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

        CardView statsCardView = (CardView) findViewById(R.id.card_view_statistics);
        statsCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor cursor = getContentResolver().query(QuizDBContract.QuizEntry.CONTENT_URI, new String[]{QuizDBContract.QuizEntry._ID},
                        null, null, null);
                int cursorCount = 0;
                if (cursor.moveToFirst()) {
                    cursorCount = cursor.getCount();
                }
                if (cursorCount <= 0) {
                    Toast.makeText(ActivityWelcomePage.this, R.string.no_stats, Toast.LENGTH_LONG).show();
                } else {
                    Intent intent = new Intent(ActivityWelcomePage.this, ActivityStatistics.class);
                    startActivity(intent);
                }
                cursor.close();
            }
        });

        ((CardView) findViewById(R.id.card_view_instructions)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityWelcomePage.this, ActivityInstructions.class);
                startActivity(intent);
            }
        });

        ((CardView) findViewById(R.id.card_view_acknowledgments)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityWelcomePage.this, ActivityAcknowledgments.class);
                startActivity(intent);
            }
        });


        // codigos do news

        getData();


    }


    private void getData()
    {
        String url = BloggerAPI.url + "?key=" + BloggerAPI.key;
        if(token != ""){
            url = url+ "&pageToken="+ token;
        }
        if(token == null){
            return;
        }
        progress.setVisibility(View.VISIBLE);
        final Call<PostList> postList = BloggerAPI.getService().getPostList(url);
        postList.enqueue(new Callback<PostList>() {
            @Override
            public void onResponse(Call<PostList> call, Response<PostList> response) {
                PostList list = response.body();
                token = list.getNextPageToken();
                items.addAll(list.getItems());
                adapter.notifyDataSetChanged();
               //Toast.makeText(MainActivityBlog.this, "Sucesso", Toast.LENGTH_SHORT).show();
                progress.setVisibility(View.GONE);
            }

            @Override
            public void onFailure(Call<PostList> call, Throwable t) {
                Toast.makeText(ActivityWelcomePage.this, "Ocorreu um erro, verifique a conexão e tente novamente", Toast.LENGTH_SHORT).show();
            }
        });

    }
    // fim codigo dos news



    @TargetApi(21)
    private void setupWindowAnimations(){
        try {
            Fade fade = (Fade) TransitionInflater.from(this).inflateTransition(R.transition.activity_fade);
            getWindow().setExitTransition(fade);
        } catch (NoClassDefFoundError e){

        }
    }

    @Override
    protected void onPause() {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        super.onPause();
    }

    private RoundedBitmapDrawable getRoundedDrawable(String filename){
        try {
            RoundedBitmapDrawable dr = RoundedBitmapDrawableFactory.create(getResources(), getAssets().open(filename));
            dr.setCornerRadius(500);
            return dr;
        }
        catch (IOException e){
//            Log.d("imageHandling", e.toString());
        }
        return null;
    }

    public void startBlog(View view) {

        Intent blog = new Intent(this, MainActivityBlog.class);
        startActivity(blog);

    }

}

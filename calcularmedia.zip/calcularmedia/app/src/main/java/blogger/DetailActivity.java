package blogger;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.judsonnunes.calcularmedia.R;


public class DetailActivity extends AppCompatActivity {

    ProgressBar progressBar;
    Toolbar toolbar;
    WebView webview;
    Float floatingActionButton;
    NavigationView navigationView;
    DrawerLayout drawerLayout;
    ActionBarDrawerToggle actionBarDrawerToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        progressBar = findViewById(R.id.progressBar);
        webview = findViewById(R.id.detailView);

        //setUpToolbar();
        //initNavigationDrawer();

        webview.setVisibility(View.INVISIBLE);
        webview.getSettings().setJavaScriptEnabled(true);
        webview.setWebChromeClient(new WebChromeClient());
        webview.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                Toast.makeText(DetailActivity.this, "Carregando", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
                webview.setVisibility(View.VISIBLE);
                Toast.makeText(DetailActivity.this, "Carregado", Toast.LENGTH_SHORT).show();
                String javaScript = "javascript:(function() { var a= document.getElementsByTagName('header');a[0].hidden='true';a=document.getElementsByClassName('page_body');a[0].style.padding='0px';})()";
                webview.loadUrl(javaScript);

            }

        });

        webview.loadUrl(getIntent().getStringExtra("url"));


        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("http://instagram.com/_u/" + "calcularmediaunip"));
                    intent.setPackage("com.instagram.android");
                    startActivity(intent);
                } catch (android.content.ActivityNotFoundException anfe) {
                    startActivity(new Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://www.instagram.com/calcularmediaunip")));
                }
            }
        });

/*
    public void initNavigationDrawer() {

        NavigationView navigationView = findViewById(R.id.navigation_menu);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                int id = menuItem.getItemId();

                switch (id) {
                    case R.id.home:
                        Intent intentHome=new Intent(getApplicationContext() ,MainActivity.class);
                        startActivity(intentHome);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "HOME", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mavaliar:
                        Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=com.judsonnunes.calcularmedia");
                        Intent intent2 = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent2);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Nos avalie com 5 estrelas <3", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mversaopro:
                        Intent intent3=new Intent(getApplicationContext() ,ActivityPagseguro.class);
                        startActivity(intent3);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Gratidão <3", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mgestao:
                        Intent intent4=new Intent(getApplicationContext() ,ActivityGestao2.class);
                        startActivity(intent4);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Gestão", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mgraduaçao:
                        Intent intent5=new Intent(getApplicationContext() ,ActivityGraduacao2.class);
                        startActivity(intent5);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Graduação", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mpraticadoc:
                        Intent intent6=new Intent(getApplicationContext() ,ActivityPraticaDocente.class);
                        startActivity(intent6);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Pratica Docente", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mtcc:
                        Intent intent7=new Intent(getApplicationContext() ,ActivityPraticaDocente.class);
                        startActivity(intent7);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Trabalho de curso", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mexame:
                        Intent intent8=new Intent(getApplicationContext() ,ActivityExame.class);
                        startActivity(intent8);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Exame", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mconsultarnotas:
                        Intent intent9=new Intent(getApplicationContext() ,ActivitySiteUnip.class);
                        startActivity(intent9);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Consultar Notas", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mduvidas:
                        Intent intent10=new Intent(getApplicationContext() ,ActivityDuvidas.class);
                        startActivity(intent10);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Dúvidas Frequentes", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mnews:
                        Intent intent11=new Intent(getApplicationContext() ,MainActivityBlog.class);
                        startActivity(intent11);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Blog News", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.msair:
                        moveTaskToBack(true);
                        android.os.Process.killProcess(android.os.Process.myPid());
                        System.exit(1);

                }
                return true;

            }
        });

        // navigation drawer
        View header = navigationView.getHeaderView(0);

        TextView tv_email = header.findViewById(R.id.tv_email);

        tv_email.setText("contatoenistudio@gmail.com");


        drawerLayout = findViewById(R.id.drawer);

        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.drawer_open,R.string.drawer_close){

            @Override

            public void onDrawerClosed(View v){

                super.onDrawerClosed(v);

            }

            @Override

            public void onDrawerOpened(View v) {

                super.onDrawerOpened(v);

            }

        };

        drawerLayout.addDrawerListener(actionBarDrawerToggle);

        actionBarDrawerToggle.syncState();
        }

    private void setUpToolbar()
    {
        drawerLayout = findViewById(R.id.drawer);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }
    // configuração de menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);


        return super.onCreateOptionsMenu(menu);

    }
    @Override
    public boolean onOptionsItemSelected (MenuItem item) {

        switch (item.getItemId())
        {




            // configurando ação menu sobre o app
            case R.id.about:
                Intent intent9=new Intent(getApplicationContext() ,ActivityAbout.class);
                startActivity(intent9);
                break;

        }


        return super.onOptionsItemSelected(item);
    }
    //aqui termina configuração de menu


*/

    }}
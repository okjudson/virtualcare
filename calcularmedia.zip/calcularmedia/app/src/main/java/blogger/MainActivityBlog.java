package blogger;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.Toast;

import com.github.ybq.android.spinkit.SpinKitView;
import com.judsonnunes.calcularmedia.ActivityAbout;
import com.judsonnunes.calcularmedia.ActivityDuvidas;
import com.judsonnunes.calcularmedia.ActivityExame;
import com.judsonnunes.calcularmedia.ActivityGestao2;
import com.judsonnunes.calcularmedia.ActivityGraduacao2;
import com.judsonnunes.calcularmedia.ActivityPagseguro;
import com.judsonnunes.calcularmedia.ActivityPraticaDocente;
import com.judsonnunes.calcularmedia.ActivitySiteUnip;
import com.judsonnunes.calcularmedia.R;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivityBlog extends AppCompatActivity {

    DrawerLayout drawerLayout;
    Toolbar toolbar;
    ActionBarDrawerToggle actionBarDrawerToggle;
    NavigationView navigationView;
    RecyclerView recyclerView;
    LinearLayoutManager manager;
    PostAdapter adapter;
    List<Item> items = new ArrayList<>();
    Boolean isScrolling = false;
    int currentItems, totalItems, scrollOutItems;
    String token = "";
    SpinKitView progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_blog);
        recyclerView = findViewById(R.id.postList);
        manager = new LinearLayoutManager(this);
        adapter = new PostAdapter(this, items);
        recyclerView.setLayoutManager(manager);
        recyclerView.setAdapter(adapter);
        progress = findViewById(R.id.spin_kit);

        setUpToolbar();

        navigationView = (NavigationView) findViewById(R.id.navigation_menu);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.home:
                        onBackPressed();
                        Toast.makeText(getApplicationContext(), "Home", Toast.LENGTH_SHORT).show();
                        drawerLayout.closeDrawers();
                        break;


                    case R.id.mavaliar:
                        Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=com.judsonnunes.calcularmedia");
                        Intent intent2 = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent2);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Nos avalie com 5 estrelas <3", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mversaopro:
                        Intent intent3=new Intent(getApplicationContext() ,ActivityPagseguro.class);
                        startActivity(intent3);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Gratidão <3", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mgestao:
                        Intent intent4=new Intent(getApplicationContext() ,ActivityGestao2.class);
                        startActivity(intent4);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Gestão", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mgraduaçao:
                        Intent intent5=new Intent(getApplicationContext() ,ActivityGraduacao2.class);
                        startActivity(intent5);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Graduação", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mpraticadoc:
                        Intent intent6=new Intent(getApplicationContext() ,ActivityPraticaDocente.class);
                        startActivity(intent6);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Pratica Docente", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mtcc:
                        Intent intent7=new Intent(getApplicationContext() ,ActivityPraticaDocente.class);
                        startActivity(intent7);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Trabalho de curso", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mexame:
                        Intent intent8=new Intent(getApplicationContext() ,ActivityExame.class);
                        startActivity(intent8);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Exame", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mconsultarnotas:
                        Intent intent9=new Intent(getApplicationContext() ,ActivitySiteUnip.class);
                        startActivity(intent9);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Consultar Notas", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mduvidas:
                        Intent intent10=new Intent(getApplicationContext() ,ActivityDuvidas.class);
                        startActivity(intent10);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Dúvidas Frequentes", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mnews:
                        Intent intent11=new Intent(getApplicationContext() ,MainActivityBlog.class);
                        startActivity(intent11);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Blog News", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.msair:
                        moveTaskToBack(true);
                        android.os.Process.killProcess(android.os.Process.myPid());
                        System.exit(1);
                }

                return false;
            }
        });

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if(newState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL)
                {
                    isScrolling = true;
                }
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                currentItems = manager.getChildCount();
                totalItems = manager.getItemCount();
                scrollOutItems = manager.findFirstVisibleItemPosition();

                if(isScrolling && (currentItems + scrollOutItems == totalItems))
                {
                    isScrolling = false;
                    getData();
                }
            }
        });
        getData();
    }



    private void setUpToolbar()
    {
        drawerLayout = findViewById(R.id.drawer);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout, toolbar,R.string.app_name, R.string.app_name);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
    }

    private void getData()
    {
        String url = BloggerAPI.url + "?key=" + BloggerAPI.key;
        if(token != ""){
            url = url+ "&pageToken="+ token;
        }
        if(token == null){
            return;
        }
        progress.setVisibility(View.VISIBLE);
        final Call<PostList> postList = BloggerAPI.getService().getPostList(url);
        postList.enqueue(new Callback<PostList>() {
            @Override
            public void onResponse(Call<PostList> call, Response<PostList> response) {
                PostList list = response.body();
                token = list.getNextPageToken();
                items.addAll(list.getItems());
                adapter.notifyDataSetChanged();
                Toast.makeText(MainActivityBlog.this, "Sucesso", Toast.LENGTH_SHORT).show();
                progress.setVisibility(View.GONE);
            }

            @Override
            public void onFailure(Call<PostList> call, Throwable t) {
                progress.setVisibility(View.GONE);
                Toast.makeText(MainActivityBlog.this, "Ocorreu um erro, verifique a conexão e tente novamente", Toast.LENGTH_SHORT).show();

            }
        });

    }
    // configuração de menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);


        return super.onCreateOptionsMenu(menu);

    }
    @Override
    public boolean onOptionsItemSelected (MenuItem item) {

        switch (item.getItemId())
        {


            // menu compartilhar com botão
            case R.id.compartilhar:
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);

                share.putExtra(Intent.EXTRA_TEXT,
                        "Recomendo esse aplicativo pra calcular a média da UNIP Interativa. \nhttps://play.google.com/store/apps/details?id=com.judsonnunes.calcularmedia");

                startActivity(Intent.createChooser(share, "Compartilhar"));
                break;

            // configurando ação menu sobre o app
            case R.id.about:
                Intent intent9=new Intent(getApplicationContext() ,ActivityAbout.class);
                startActivity(intent9);
                break;

        }


        return super.onOptionsItemSelected(item);
    }
    //aqui termina configuração de menu

}

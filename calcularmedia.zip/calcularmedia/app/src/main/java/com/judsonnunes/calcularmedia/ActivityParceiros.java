package com.judsonnunes.calcularmedia;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import blogger.MainActivityBlog;

public class ActivityParceiros extends AppCompatActivity {


    private static final int PERMISSION_REQUEST_CODE = 100;
    private DrawerLayout drawerLayout;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parceiros);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        initNavigationDrawer();


        //navigation drawer


    }


    public void initNavigationDrawer() {

        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                int id = menuItem.getItemId();

                switch (id) {
                    case R.id.home:
                        onBackPressed();
                        Toast.makeText(getApplicationContext(), "Home", Toast.LENGTH_SHORT).show();
                        drawerLayout.closeDrawers();
                        break;


                    case R.id.mavaliar:
                        Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=com.judsonnunes.calcularmedia");
                        Intent intent2 = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent2);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Nos avalie com 5 estrelas <3", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mversaopro:
                        Intent intent3 = new Intent(getApplicationContext(), ActivityPagseguro.class);
                        startActivity(intent3);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Gratidão <3", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mgestao:
                        Intent intent4 = new Intent(getApplicationContext(), ActivityGestao2.class);
                        startActivity(intent4);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Gestão", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mgraduaçao:
                        Intent intent5 = new Intent(getApplicationContext(), ActivityGraduacao2.class);
                        startActivity(intent5);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Graduação", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mpraticadoc:
                        Intent intent6 = new Intent(getApplicationContext(), ActivityPraticaDocente.class);
                        startActivity(intent6);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Pratica Docente", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mtcc:
                        Intent intent7 = new Intent(getApplicationContext(), ActivityPraticaDocente.class);
                        startActivity(intent7);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Trabalho de curso", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mexame:
                        Intent intent8 = new Intent(getApplicationContext(), ActivityExame.class);
                        startActivity(intent8);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Exame", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mconsultarnotas:
                        uri = Uri.parse("https://gfa.unip.br/aluno/");
                        Intent intent23 = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent23);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Carregando Site no navegador", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.mduvidas:
                        Intent intent10 = new Intent(getApplicationContext(), ActivityDuvidas.class);
                        startActivity(intent10);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Dúvidas Frequentes", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mnews:
                        Intent intent11=new Intent(getApplicationContext() , MainActivityBlog.class);
                        startActivity(intent11);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Blog News", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.instagram:
                        startInstagram();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Segue a gente <3", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.msair:
                        moveTaskToBack(true);
                        android.os.Process.killProcess(android.os.Process.myPid());
                        System.exit(1);

                }
                return true;

            }

            private void startInstagram() {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("http://instagram.com/_u/" + "calcularmediaunip"));
                    intent.setPackage("com.instagram.android");
                    startActivity(intent);
                }
                catch (android.content.ActivityNotFoundException anfe)
                {
                    startActivity(new Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://www.instagram.com/calcularmediaunip")));
                }
            }
        });

        // navigation drawer
        View header = navigationView.getHeaderView(0);

        TextView tv_email = (TextView) header.findViewById(R.id.tv_email);

        tv_email.setText("contatoenistudio@gmail.com");


        drawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.drawer_open, R.string.drawer_close) {

            @Override

            public void onDrawerClosed(View v) {

                super.onDrawerClosed(v);

            }

            @Override

            public void onDrawerOpened(View v) {

                super.onDrawerOpened(v);

            }

        };

        drawerLayout.addDrawerListener(actionBarDrawerToggle);

        actionBarDrawerToggle.syncState();
    }


//codigos do navigation drawer

    // botoes
    public void startPagae(View view) {

        Uri uri = Uri.parse("https://pag.ae/bhwYFdz");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }

    public void startAvaliar(View view) {

        Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=com.judsonnunes.calcularmedia");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
        Toast.makeText(getApplicationContext(), "Nos avalie com 5 estrelas <3", Toast.LENGTH_SHORT).show();
    }

    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("EXIT", true);
        startActivity(intent);
        finish();
    }
    //aqui passa o string para abrir o intent do app de ligação do telefone -
    public void callCelular(View view) {
        TextView campoTelefone = (TextView) findViewById(R.id.edTelefone1);
        String telefone = campoTelefone.getText().toString();
        Uri uri = Uri.parse("tel:"+telefone);
        Intent intent = new Intent(Intent.ACTION_DIAL,uri);
        startActivity(intent);
    }

    public void callFixo(View view) {
        TextView campoTelefone = (TextView) findViewById(R.id.edTelefone2);
        String telefone = campoTelefone.getText().toString();
        Uri uri = Uri.parse("tel:"+telefone);
        Intent intent = new Intent(Intent.ACTION_DIAL,uri);
        startActivity(intent);
    }

    public void startWhatsApp(View view) {

        Uri uri = Uri.parse("http://bit.ly/2LLLX10");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }
}
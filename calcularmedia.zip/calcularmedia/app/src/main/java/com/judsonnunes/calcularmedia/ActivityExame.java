package com.judsonnunes.calcularmedia;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.Locale;

import blogger.MainActivityBlog;

public class ActivityExame extends AppCompatActivity {

    // Aqui vai a primeira parte do admob banner

    private AdView mAdView;
    private Toolbar toolbar;
    private DrawerLayout drawerLayout;
    // Aqui vai a primeira parte do admob banner

    EditText edtmedia, edtexame;
    Button btncalc3;
    private Bitmap mBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exame);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        initNavigationDrawer();



        //navigation drawer
        MobileAds.initialize(this, "ca-app-pub-8537266085420592/9567236218");
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

    }

    public void initNavigationDrawer() {

        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation_view);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                int id = menuItem.getItemId();

                switch (id) {
                    case R.id.home:
                        onBackPressed();
                        Toast.makeText(getApplicationContext(), "Home", Toast.LENGTH_SHORT).show();
                        drawerLayout.closeDrawers();
                        break;


                    case R.id.mavaliar:
                        Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=com.judsonnunes.calcularmedia");
                        Intent intent2 = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent2);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Nos avalie com 5 estrelas <3", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mversaopro:
                        Intent intent3=new Intent(getApplicationContext() ,ActivityPagseguro.class);
                        startActivity(intent3);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Gratidão <3", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mgestao:
                        Intent intent4=new Intent(getApplicationContext() ,ActivityGestao2.class);
                        startActivity(intent4);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Gestão", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mgraduaçao:
                        Intent intent5=new Intent(getApplicationContext() ,ActivityGraduacao2.class);
                        startActivity(intent5);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Graduação", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mpraticadoc:
                        Intent intent6=new Intent(getApplicationContext() ,ActivityPraticaDocente.class);
                        startActivity(intent6);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Pratica Docente", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mtcc:
                        Intent intent7=new Intent(getApplicationContext() ,ActivityPraticaDocente.class);
                        startActivity(intent7);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Trabalho de curso", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mexame:
                        Intent intent8=new Intent(getApplicationContext() ,ActivityExame.class);
                        startActivity(intent8);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Exame", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mconsultarnotas:
                        uri = Uri.parse("https://gfa.unip.br/aluno/");
                        Intent intent23 = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent23);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Carregando Site no navegador", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mduvidas:
                        Intent intent10=new Intent(getApplicationContext() ,ActivityDuvidas.class);
                        startActivity(intent10);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Dúvidas Frequentes", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mnews:
                        Intent intent11=new Intent(getApplicationContext() , MainActivityBlog.class);
                        startActivity(intent11);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Blog News", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.instagram:
                        startInstagram();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Segue a gente <3", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.msair:
                        moveTaskToBack(true);
                        android.os.Process.killProcess(android.os.Process.myPid());
                        System.exit(1);

                }
                return true;

            }

            private void startInstagram() {

                    try {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("http://instagram.com/_u/" + "calcularmediaunip"));
                    intent.setPackage("com.instagram.android");
                    startActivity(intent);
                }
                catch (android.content.ActivityNotFoundException anfe)
                {
                    startActivity(new Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://www.instagram.com/calcularmediaunip")));
                }
        }

                    });

        // navigation drawer
        View header = navigationView.getHeaderView(0);

        TextView tv_email = (TextView)header.findViewById(R.id.tv_email);

        tv_email.setText("contatoenistudio@gmail.com");


        drawerLayout = (DrawerLayout)findViewById(R.id.drawer);

        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.drawer_open,R.string.drawer_close){

            @Override

            public void onDrawerClosed(View v){

                super.onDrawerClosed(v);

            }

            @Override

            public void onDrawerOpened(View v) {

                super.onDrawerOpened(v);

            }

        };

        drawerLayout.addDrawerListener(actionBarDrawerToggle);

        actionBarDrawerToggle.syncState();





//codigos do navigation drawer



        //definindo logo do app no action bar
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setHomeAsUpIndicator(R.mipmap.ic_seistransparente);

        // Aqui vai a segunda parte do admob banner
        // Aqui vai a segunda parte do admob banner
        // Aqui vai a segunda parte do admob banner
        // adm banner
        AdView adView = new AdView(this);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId("ca-app-pub-8537266085420592/9567236218");

        // Aqui vai a segunda parte do admob banner

           // resgatando o que foi digitado no editText

            edtmedia = (EditText) findViewById(R.id.edtava);
            edtexame = (EditText) findViewById(R.id.edtaval);



            // resgatando o botão declarado
            btncalc3 = (Button) findViewById(R.id.btncalc3);



            // adicionando a ação do botão somar
            btncalc3.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View View) {
// aqui pra conferir se tem texto digitado dentro do edti text apanhei demais pra consegui fazer
// o segredo e definir o if caso não tenha texto e o restante do código para else
                            if(edtexame.getText().toString().equals("") || edtmedia.getText().toString().equals(""))
                            {
                                AlertDialog.Builder dialogos = new AlertDialog.Builder(ActivityExame.this);
                                dialogos.setIcon(R.drawable.alerta);
                                dialogos.setTitle("ERRO");
                                dialogos.setMessage("Preencha todos os campos.");
                                dialogos.setNeutralButton("OK", null);
                                // chamando o AlertDialog
                                dialogos.show();
                            } else {
                    // declaração de variáveis

                    // resgata valor digitado no primeiro campo
                    double num1 = Double.parseDouble(edtmedia.getText().toString());

                    // resgata valor digitado no segundo campo
                    double num2 = Double.parseDouble(edtexame.getText().toString());

                    // o resultado media final
                    double mediafinal = (num1 + num2) / 2;
                    // definindo casas decimais que vão ser mostradas pra não ficar 4.0000000001
                    Locale.setDefault(Locale.US);
                    NumberFormat format = NumberFormat.getInstance();
                    format.setMaximumFractionDigits(2);
                    format.setMinimumFractionDigits(2);
                    format.setMaximumIntegerDigits(2);
                    format.setRoundingMode(RoundingMode.HALF_UP);
                    mediafinal = Double.valueOf(format.format(mediafinal));



                    // preparando alertDialog e setando valores
                    AlertDialog.Builder dialogo = new AlertDialog.Builder(ActivityExame.this);
                    // Instância
                   if (mediafinal >= 5.0) {
                        //definindo icone
                        dialogo.setIcon(R.drawable.rindo);
                        // setando título
                        dialogo.setTitle("APROVADO");
                        // setando mensagem
                        dialogo.setMessage("Parabéns! \nAlcançou média: " + mediafinal + " parabéns :)");
                        // setando botão
                        dialogo.setNeutralButton("OK", null);
                        // chamando o AlertDialog
                        dialogo.show();
                       // chamar interticial iniciio
                       //launchInter();
                       //loadInterstitial(); - IMPLEMENTAR EM NOVA VERSÃO INTERTICIAL
                       // chamar interticial final
                       // chamando o AlertDialog
                       dialogo.show();
                   }  else if (mediafinal >= 4.75 ){
                       //definindo icone
                       dialogo.setIcon(R.drawable.feliz);
                       // setando título
                       dialogo.setTitle("EM CIMA DO MURO");
                       // setando mensagem
                       dialogo.setMessage("Sua média foi de: " + mediafinal +" - No entanto, segundo o manual quando a MF for maior ou igual a 4,75(quatro vírgula setenta e cinco) e menor que 5,0 (cinco), a MF será arredondada para 5,0 (cinco), seguindo esse parâmetro você está aprovado, mas recomendamos que verifique com seu polo, pois pelo que consta esse arredondamento é válido para alunos ingressantes a partir de 2011. Bons estudos, vai dar tudo certo.");
                       // setando botão
                       dialogo.setNeutralButton("OK", null);
                       // chamando o AlertDialog
                       dialogo.show();
                   } else {
                        //definindo icone
                        dialogo.setIcon(R.drawable.neutro);
                        // setando título
                        dialogo.setTitle("REPROVADO");
                        // setando mensagem
                        dialogo.setMessage("A média mínima é 5.0 pontos você alcançou: " + mediafinal);
                        // setando botão
                        dialogo.setNeutralButton("OK", null);
                        // chamando o AlertDialog
                        dialogo.show();
                    }
                }

            }
                //aqui coloca um );} quando inseri o if para ver se tem texto digitado
        });}



    // aqui começa configuração de menu
    // configuração de menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu2, menu);


        return super.onCreateOptionsMenu(menu);

    }
    @Override
    public boolean onOptionsItemSelected (MenuItem item) {

        switch (item.getItemId())
        {


            // menu compartilhar com botão
            case R.id.compartilhar:
                Intent share = new Intent(android.content.Intent.ACTION_SEND);
                share.setType("text/plain");
                share.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);

                share.putExtra(Intent.EXTRA_TEXT,
                        "Recomendo esse aplicativo pra calcular a média da UNIP Interativa. \nhttps://play.google.com/store/apps/details?id=com.judsonnunes.calcularmedia");

                startActivity(Intent.createChooser(share, "Compartilhar"));
                break;

            // configurando ação menu sobre o app
            case R.id.about:
                Intent intent9=new Intent(getApplicationContext() ,ActivityAbout.class);
                startActivity(intent9);
                break;
        }


        return super.onOptionsItemSelected(item);
    }
    //aqui termina configuração de menu



// configurando método da toolbar

// final metodo toolbar

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("EXIT", true);
        startActivity(intent);
        finish();
    }

}
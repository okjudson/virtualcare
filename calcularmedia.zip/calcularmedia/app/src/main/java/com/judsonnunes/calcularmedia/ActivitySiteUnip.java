package com.judsonnunes.calcularmedia;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;

public class ActivitySiteUnip extends AppCompatActivity {

    private static final String URL = "https://mail.google.com";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity_site_unip);
        //definindo logo do app no action bar
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setHomeAsUpIndicator(R.mipmap.ic_paginaweb);



        /*/webview
        WebView webView;
        webView = (WebView) findViewById(R.id.webView);
        webView.loadUrl("");
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());;
        webView.getSettings().setBuiltInZoomControls(true);
        webView.invokeZoomPicker();
        webView.clearCache(true);
        webView.getSettings().setPluginState(WebSettings.PluginState.ON);
        webView.clearSslPreferences();
        CookieManager.getInstance().setAcceptCookie(true);

        resolve https ssl/*/


    }

    public void startSite(View view) {

        Uri uri = Uri.parse("https://gfa.unip.br/aluno/");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
//Handle the back button
        if(keyCode == KeyEvent.KEYCODE_BACK) {
            Intent voltahome = new Intent(this, MainActivity.class);
            startActivity(voltahome);
            finish();
        } else {
            return super.onKeyDown(keyCode, event);
        }

        return false;
    }
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("EXIT", true);
        startActivity(intent);
        finish();
    }
}
package com.judsonnunes.calcularmedia;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.Locale;

import blogger.MainActivityBlog;


public class ActivityGestao extends AppCompatActivity {
    // Aqui começa a primeira parte do código do admob inter

    private InterstitialAd interstitialAd;
    boolean exitApp = false;
    private Toolbar toolbar;
    private DrawerLayout drawerLayout;

    // Aqui acaba a primeira parte do código do admob inter

    // Aqui vai a primeira parte do admob banner

    private AdView mAdView;

    // Aqui vai a primeira parte do admob banner

    EditText edtpim;
    EditText edtAva;
    EditText edtAval;
    Button btncalc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestao);
        //definindo logo do app no action bar
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setHomeAsUpIndicator(R.mipmap.ic_seistransparente);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        initNavigationDrawer();



        //navigation drawer


    }

    public void initNavigationDrawer() {

        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation_view);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                int id = menuItem.getItemId();

                switch (id) {
                    case R.id.home:
                        onBackPressed();
                        Toast.makeText(getApplicationContext(), "Home", Toast.LENGTH_SHORT).show();
                        drawerLayout.closeDrawers();
                        break;


                    case R.id.mavaliar:
                        Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=com.judsonnunes.calcularmedia");
                        Intent intent2 = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent2);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Nos avalie com 5 estrelas <3", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mversaopro:
                        Intent intent3=new Intent(getApplicationContext() ,ActivityPagseguro.class);
                        startActivity(intent3);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Gratidão <3", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mgestao:
                        Intent intent4=new Intent(getApplicationContext() ,ActivityGestao2.class);
                        startActivity(intent4);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Gestão", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mgraduaçao:
                        Intent intent5=new Intent(getApplicationContext() ,ActivityGraduacao2.class);
                        startActivity(intent5);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Graduação", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mpraticadoc:
                        Intent intent6=new Intent(getApplicationContext() ,ActivityPraticaDocente.class);
                        startActivity(intent6);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Pratica Docente", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mtcc:
                        Intent intent7=new Intent(getApplicationContext() ,ActivityPraticaDocente.class);
                        startActivity(intent7);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Trabalho de curso", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mexame:
                        Intent intent8=new Intent(getApplicationContext() ,ActivityExame.class);
                        startActivity(intent8);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Exame", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mconsultarnotas:
                        Intent intent9=new Intent(getApplicationContext() ,ActivitySiteUnip.class);
                        startActivity(intent9);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Consultar Notas", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mduvidas:
                        Intent intent10=new Intent(getApplicationContext() ,ActivityDuvidas.class);
                        startActivity(intent10);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Dúvidas Frequentes", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mnews:
                        Intent intent11=new Intent(getApplicationContext() , MainActivityBlog.class);
                        startActivity(intent11);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Blog News", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.msair:
                        moveTaskToBack(true);
                        android.os.Process.killProcess(android.os.Process.myPid());
                        System.exit(1);

                }
                return true;

            }
        });

        // navigation drawer
        View header = navigationView.getHeaderView(0);

        TextView tv_email = (TextView)header.findViewById(R.id.tv_email);

        tv_email.setText("contatoenistudio@gmail.com");


        drawerLayout = (DrawerLayout)findViewById(R.id.drawer);

        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.drawer_open,R.string.drawer_close){

            @Override

            public void onDrawerClosed(View v){

                super.onDrawerClosed(v);

            }

            @Override

            public void onDrawerOpened(View v) {

                super.onDrawerOpened(v);

            }

        };

        drawerLayout.addDrawerListener(actionBarDrawerToggle);

        actionBarDrawerToggle.syncState();







        // Aqui vai a segunda parte do admob banner

        AdView mAdView = (AdView) findViewById(R.id.mAdView);
        AdRequest adRequest = new AdRequest.Builder()
                .addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                .addTestDevice("3FA4A388290A5364D596C82712DFED1D") // Aqui vai o código do dispositivo de teste
                .addTestDevice("CC9C9E2519CDFACB591147FBA79C0DC2")//  dispositivo de teste Motorola MotoE1g
                .build();
        mAdView.loadAd(adRequest);

        // Aqui vai a segunda parte do admob banner


// resgatando o que foi digitado no editText

        edtpim = (EditText) findViewById(R.id.edtpim);
        edtAva = (EditText) findViewById(R.id.edtava);
        edtAval = (EditText) findViewById(R.id.edtaval);





// resgatando o botão declarado

        btncalc = (Button) findViewById(R.id.btncalc);

// adicionando a ação do botão somar
        btncalc.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                // aqui pra conferir se tem texto digitado dentro do edti text apanhei demais pra consegui fazer
// o segredo e definir o if caso não tenha texto e o restante do código para else
                if(edtpim.getText().toString().equals("") || edtAva.getText().toString().equals("")
                        || edtAval.getText().toString().equals(""))
                {
                    AlertDialog.Builder dialogos = new AlertDialog.Builder(ActivityGestao.this);
                    dialogos.setIcon(R.drawable.alerta);
                    dialogos.setTitle("ERRO");
                    dialogos.setMessage("Preencha todos os campos.");
                    dialogos.setNeutralButton("OK", null);
                    // chamando o AlertDialog
                    dialogos.show();
                } else {

                // declaração de variáveis

                // regata valor digitado no primeiro campo
                double num1 = Double.parseDouble(edtpim.getText().toString());
                // regata valor digitado no segundo campo
                double num2 = Double.parseDouble(edtAva.getText().toString());
                // regata valor digitado no terceiro campo
                double num3 = Double.parseDouble(edtAval.getText().toString());
                // o resultado media 0
                double media0 = (num1 * 9 + num2) / 10;
                // o resultado media 1
                double media1 = (num3 * 3);
                // resultado media final
                double mediafinal = (media0 + media1) / 4;
                // definindo casas decimais que vão ser mostradas pra não ficar 4.0000000001
                Locale.setDefault(Locale.US);
                NumberFormat format = NumberFormat.getInstance();
                format.setMaximumFractionDigits(2);
                format.setMinimumFractionDigits(2);
                format.setMaximumIntegerDigits(2);
                format.setRoundingMode(RoundingMode.HALF_UP);
                mediafinal = Double.valueOf(format.format(mediafinal));

                //chegar nota mínima para exame
                double mediaexame = (9.8 - mediafinal);
                // definindo casas decimais que vão ser mostradas pra não ficar 4.0000000001
                Locale.setDefault(Locale.US);
                format = NumberFormat.getInstance();
                format.setMaximumFractionDigits(2);
                format.setMinimumFractionDigits(2);
                format.setMaximumIntegerDigits(2);
                format.setRoundingMode(RoundingMode.HALF_UP);
                mediaexame = Double.valueOf(format.format(mediaexame));


                // preparando alertDialog e setando valores
                // Instância
                AlertDialog.Builder dialogo = new AlertDialog.Builder(ActivityGestao.this);
                if (mediafinal >= 6.0){
                    //definindo icone
                    dialogo.setIcon(R.drawable.rindo);
                    // setando título
                    dialogo.setTitle("APROVADO");
                    // setando mensagem
                    dialogo.setMessage("Parabéns! \nAlcançou média: " + mediafinal + " - Continue assim :)");
                    // setando botão
                    dialogo.setNeutralButton("OK", null);
                    // chamar interticial iniciio
                    launchInter();
                    loadInterstitial();
                    // chamar interticial final
                    // chamando o AlertDialog
                    dialogo.show();
                }  else if (mediafinal >= 5.7 ){
                    //definindo icone
                    dialogo.setIcon(R.drawable.feliz);
                    // setando título
                    dialogo.setTitle("EM CIMA DO MURO");
                    // setando mensagem
                    dialogo.setMessage("Sua média foi de: " + mediafinal +" - No entanto, segundo o manual toda média maior ou igual a 5.7 e menor que 6.0 é arredondada para 6.0, seguindo esse parâmetro você está aprovado, mas recomendamos que verifique com seu polo, pois pelo que consta esse arredondamento é válido para alunos ingressantes a partir de 2011. Boas vibrações, vai dar tudo certo.");
                    // setando botão
                    dialogo.setNeutralButton("OK", null);
                    // chamando o AlertDialog
                    dialogo.show();
                }
                else {
                    //definindo icone
                    dialogo.setIcon(R.drawable.neutro);
                    // setando título
                    dialogo.setTitle("PEGOU EXAME");
                    // setando mensagem
                    dialogo.setMessage("Alcançou média: " + mediafinal + "\nEstá de exame e precisa tirar nota mínima de " + mediaexame + " pontos para passar. \nBoa Sorte!");
                    // setando botão
                    dialogo.setNeutralButton("OK", null);
                    // chamando o AlertDialog
                    dialogo.show();
                }
            }
        }
            //aqui coloca um );} quando inseri o if para ver se tem texto digitado
    });}

    // aqui começa configuração de menu
    // configuração de menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu2, menu);


        return super.onCreateOptionsMenu(menu);

    }
    @Override
    public boolean onOptionsItemSelected (MenuItem item) {

        switch (item.getItemId())
        {
            // menu compartilhar com botão
            case R.id.compartilhar:
                Intent share = new Intent(android.content.Intent.ACTION_SEND);
                share.setType("text/plain");
                share.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);

                share.putExtra(Intent.EXTRA_TEXT,
                        "Recomendo esse aplicativo pra calcular a média da UNIP Interativa. \nhttps://play.google.com/store/apps/details?id=com.judsonnunes.calcularmedia");

                startActivity(Intent.createChooser(share, "Compartilhar"));
                break;

            // configurando ação menu sobre o app
            case R.id.about:
                Intent intent9=new Intent(getApplicationContext() ,ActivityAbout.class);
                startActivity(intent9);
                break;

        }


        return super.onOptionsItemSelected(item);
    }
    //aqui termina configuração de menu
    ///Aqui começa a terceira parte do admob

    private void launchInter() {

        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId("ca-app-pub-8537266085420592/8310987410");  // ID do admob insterticial ca-app-pub-8537266085420592/2043969414

        //set the adListener

        interstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                showAdInter();
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                String message = String.format("onAdFailedToLoad (%s)", getErrorReason(errorCode));
            }

            @Override
            public void onAdClosed() {
                if (exitApp)
                    finish();
            }
        });
    }

    private void showAdInter() {

        if (interstitialAd.isLoaded()) {
            interstitialAd.show();
        } else {
            Log.d("", "Interstitial ad was not ready to be show");
        }
    }

    public void loadInterstitial() {

        AdRequest adrequest = new AdRequest.Builder()
                .addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                .addTestDevice("3FA4A388290A5364D596C82712DFED1D")   // id telefone testepai mi B5186BD79890A7A6CFB60C2A41A4B9C0 "".
                .addTestDevice("CC9C9E2519CDFACB591147FBA79C0DC2")//  dispositivo de teste Motorola MotoE1g
                .build();

        // Load the Interstitial ad

        interstitialAd.loadAd(adrequest);
    }
    // Chamar displayInterstitial() quando você estiver pronto para exibir um intersticial.
    public void displayInterstitial() {
        if (interstitialAd.isLoaded()) {
            interstitialAd.show();
        }}

    //Get a String error reason from and error code

    private String getErrorReason(int errorCode) {
        String errorReason = "";
        switch (errorCode) {
            case AdRequest.ERROR_CODE_INTERNAL_ERROR:
                errorReason = "Internal Error";
                break;
            case AdRequest.ERROR_CODE_INVALID_REQUEST:
                errorReason = "Invalid Request";
                break;
            case AdRequest.ERROR_CODE_NETWORK_ERROR:
                errorReason = "Network Error";
                break;
            case AdRequest.ERROR_CODE_NO_FILL:
                errorReason = "No fill";
                break;
        }
        return errorReason;
    }

// Aqui Termina a Terceira Parte do código do Admob

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("EXIT", true);
        startActivity(intent);
        finish();
    }
}




package com.judsonnunes.calcularmedia;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.ybq.android.spinkit.SpinKitView;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.List;

import blogger.BloggerAPI;
import blogger.Item;
import blogger.MainActivityBlog;
import blogger.PostAdapter;
import blogger.PostList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    // codigos do na navigation drawer
    private DrawerLayout drawerLayout;
    private Toolbar toolbar;
    // fim nav drawer

    // Aqui acaba a primeira parte do código do admob interti

    // Aqui vai a primeira parte do admob



    // Aqui vai a primeira parte do admob

    private Button bt_gestao2, bt_graduacao2,  bt_notas2, bt_praticadoc2, bt_duvidas2, bt_tcc2;

    private ImageView img_card, img_pagseguro;
    private AdView mAdView;


    ActionBarDrawerToggle actionBarDrawerToggle;
    NavigationView navigationView;
    RecyclerView recyclerView;
    LinearLayoutManager manager;
    PostAdapter adapter;
    List<Item> items = new ArrayList<>();
    Boolean isScrolling = false;
    int currentItems, totalItems, scrollOutItems;
    String token = "";
    SpinKitView progress;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_up);
        //toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        //getSupportActionBar().hide();//Ocultar ActivityBar anterior

        recyclerView = findViewById(R.id.postList);
        manager = new LinearLayoutManager(this);
        adapter = new PostAdapter(this, items);
        recyclerView.setLayoutManager(manager);
        recyclerView.setAdapter(adapter);
        progress = findViewById(R.id.spin_kit);

        initNavigationDrawer();
        getData();


        MobileAds.initialize(this, "ca-app-pub-8537266085420592/9567236218");
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


    }

    public void initNavigationDrawer() {

        NavigationView navigationView = findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                int id = menuItem.getItemId();

                switch (id) {
                    case R.id.home:
                        Toast.makeText(getApplicationContext(), "Home", Toast.LENGTH_SHORT).show();
                        drawerLayout.closeDrawers();
                        break;


                    case R.id.mavaliar:
                        Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=com.judsonnunes.calcularmedia");
                        Intent intent2 = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent2);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Nos avalie com 5 estrelas <3", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mversaopro:
                        Intent intent3=new Intent(getApplicationContext() ,ActivityPagseguro.class);
                        startActivity(intent3);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Gratidão <3", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mgestao:
                        Intent intent4=new Intent(getApplicationContext() ,ActivityGestao2.class);
                        startActivity(intent4);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Gestão", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mgraduaçao:
                        Intent intent5=new Intent(getApplicationContext() ,ActivityGraduacao2.class);
                        startActivity(intent5);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Graduação", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mpraticadoc:
                        Intent intent6=new Intent(getApplicationContext() ,ActivityPraticaDocente.class);
                        startActivity(intent6);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Pratica Docente", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mtcc:
                        Intent intent7=new Intent(getApplicationContext() ,ActivityPraticaDocente.class);
                        startActivity(intent7);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Trabalho de curso", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mexame:
                        Intent intent8=new Intent(getApplicationContext() ,ActivityExame.class);
                        startActivity(intent8);
                        finish();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Exame", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mconsultarnotas:
                        uri = Uri.parse("https://gfa.unip.br/aluno/");
                        Intent intent23 = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent23);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Carregando Site no navegador", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mduvidas:
                        Intent intent10=new Intent(getApplicationContext() ,ActivityDuvidas.class);
                        startActivity(intent10);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Dúvidas Frequentes", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.mnews:
                        Intent intent11=new Intent(getApplicationContext() ,MainActivityBlog.class);
                        startActivity(intent11);
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Blog News", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.instagram:
                        startInstagram();
                        drawerLayout.closeDrawers();
                        Toast.makeText(getApplicationContext(), "Segue a gente <3", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.msair:
                        moveTaskToBack(true);
                        android.os.Process.killProcess(android.os.Process.myPid());
                        System.exit(1);

                }
                return true;

            }
        });





        // navigation drawer
        View header = navigationView.getHeaderView(0);

        TextView tv_email = header.findViewById(R.id.tv_email);

        tv_email.setText("contatoenistudio@gmail.com");


        drawerLayout = findViewById(R.id.drawer);

        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar, R.string.drawer_open, R.string.drawer_close){

            @Override

            public void onDrawerClosed(View v){

                super.onDrawerClosed(v);

            }

            @Override

            public void onDrawerOpened(View v) {

                super.onDrawerOpened(v);

            }

        };

        drawerLayout.addDrawerListener(actionBarDrawerToggle);

        actionBarDrawerToggle.syncState();


//

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if(newState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL)
                {
                    isScrolling = true;
                }
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                currentItems = manager.getChildCount();
                totalItems = manager.getItemCount();
                scrollOutItems = manager.findFirstVisibleItemPosition();

                if(isScrolling && (currentItems + scrollOutItems == totalItems))
                {
                    isScrolling = false;
                    getData();
                }
            }
        });
        getData();
    }

    private void startInstagram() {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("http://instagram.com/_u/" + "calcularmediaunip"));
                intent.setPackage("com.instagram.android");
                startActivity(intent);
            }
            catch (android.content.ActivityNotFoundException anfe)
            {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.instagram.com/calcularmediaunip")));
            }
        }



    private void setUpToolbar()
    {
        drawerLayout = findViewById(R.id.drawer);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout, toolbar,R.string.app_name, R.string.app_name);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
    }

    private void getData()
    {
        String url = BloggerAPI.url + "?key=" + BloggerAPI.key;
        if(token != ""){
            url = url+ "&pageToken="+ token;
        }
        if(token == null){
            return;
        }
        progress.setVisibility(View.VISIBLE);
                             final Call<PostList> postList = BloggerAPI.getService().getPostList(url);
        postList.enqueue(new Callback<PostList>() {
            @Override
            public void onResponse(Call<PostList> call, Response<PostList> response) {
                PostList list = response.body();
                token = list.getNextPageToken();
                items.addAll(list.getItems());
                adapter.notifyDataSetChanged();
                //Toast.makeText(MainActivity.this, "Bem Vindo!", Toast.LENGTH_SHORT).show();
                progress.setVisibility(View.GONE);
            }

            @Override
            public void onFailure(Call<PostList> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Ocorreu um erro, verifique a conexão e tente novamente", Toast.LENGTH_SHORT).show();
            }
        });


        //



//codigos do navigation drawer


        bt_gestao2 = findViewById(R.id.bt_gestao2);
        bt_graduacao2 = findViewById(R.id.bt_graduacao2);
        bt_notas2 = findViewById(R.id.bt_notas2);

        bt_duvidas2 = findViewById(R.id.bt_duvidas2);



        //getSupportActionBar().setDisplayHomeAsUpEnabled(Boolean.parseBoolean(null));
        //getSupportActionBar().setHomeAsUpIndicator(R.mipmap.ic_seistransparente);


        // Aqui começa a segunda parte do código do admob intersticial
        //aqui tinha código admob interticial mas não é legal com a politica google então foi removido
        // Aqui termina a segunda parte do código do admob intersticial

        // Aqui vai a segunda parte do admob banner
        AdView adView = new AdView(this);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId("ca-app-pub-8537266085420592/9567236218");
        /*       AdRequest adRequest = new AdRequest.Builder()
                .addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                .addTestDevice("3FA4A388290A5364D596C82712DFED1D") // dispositivo de teste LENOVO vibeA7010
                .addTestDevice("CC9C9E2519CDFACB591147FBA79C0DC2")//  dispositivo de teste Motorola MotoE1g
                .build();
                AdView.loadAd(adRequest);
         */
// TODO: Add adView to your view hierarchy.


    }






 /* // sair clicanco no voltar do celular
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
//Handle the back button
        if(keyCode == KeyEvent.KEYCODE_BACK) {
            AlertDialog.Builder dialogosair = new AlertDialog.Builder(MainActivity.this);
            //setando título
            dialogosair.setTitle("VERSÃO PRO");
            // setando mensagem
            dialogosair.setMessage("Agora temos uma versão PRO, sem anúncios, mais estável e em breve com funcionalidades exclusivas, por apenas R$1,00.  \nPedimos também para que nos avalie na Play Store com 5 estrelas. \nObrigado :)");
            // setando para avaliar na playstore
            dialogosair.setNeutralButton("AVALIAR", neprivate void startActivityGestao() {
    }w DialogInterface.OnClickListener(){
                public void onClick(DialogInterface dialog, int which) {
                    String url = "https://play.google.com/store/apps/details?id=com.judsonnunes.calcularmedia";
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                    // aqui podemos fechar o app com - finish();
                    // mas vamos chamar a activity pra iluminar com a tela


                }

            });
            // setando botão APP
            dialogosair.setNegativeButton("APP PRO", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    String url = "https://play.google.com/store/apps/details?id=com.judsonnunes.calcularmediaPro";
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                    // aqui podemos fechar o app com - finish();
                    // mas vamos chamar a activity pra iluminar com a tela


                }

            });

            // setando botão
            dialogosair.setPositiveButton(" SAIR ", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {

                    //Stop the activity
                    MainActivity.this.finish();
                    // Aqui começa a segunda parte do código do admob
                    //tirei pra fazer propaganda do app pro
                    //launchInter();
                    //loadInterstitial();

                    // Aqui termina a segunda parte do código do admob
                }

            });
            // chamando o AlertDialog
            dialogosair.show();
            return true;
        } else {
            return super.onKeyDown(keyCode, event);
            }

        }

//reiranto o arteristico e a barra para usar o codigo
*/

    public void startBlog(View view) {

        Intent blog = new Intent(this, MainActivityBlog.class);
        startActivity(blog);

    }

 public void startActivityPraticadoc(View view) {

     Intent startParceiros = new Intent(this, ActivityPraticaDocente.class);
     startActivity(startParceiros);
 }
    // chamando activity gestão
    public void startActivityGestao(View view) {

        Intent telagestao = new Intent(this, ActivityGestao.class);
        startActivity(telagestao);

    }

    // chamando activity graduação
    public void startActivityGraduacao(View view) {

        Intent secondActivity = new Intent(this, ActivityGraduacao.class);
        // Chamando interticial
        //launchInter();
        //loadInterstitial();
        // chamando interticial
        startActivity(secondActivity);


    }

    //chamar activity
    public void startActivityGraduacao2 (View view) {

        Intent secondActivity2 = new Intent(this, ActivityGraduacao2.class);
        startActivity(secondActivity2);


    }

    public void startActivityGestao2 (View view) {

        Intent secondActivity4 = new Intent(this, ActivityGestao2.class);
        startActivity(secondActivity4);


    }

    // chamando activity com tela para novos calculos 2018
    public void startActivityFormula2018(View view) {

        Intent secondActivity = new Intent(this, ActivityFormula2018.class);
        startActivity(secondActivity);
    }


    // chamando activity exame
    public void startActivityExame(View view) {

        Intent secondActivity = new Intent(this, ActivityExame.class);
        startActivity(secondActivity);
    }

    //implementado em 28/06/2016
    // chamando tela para usuário avaliar aplicativo
    public void startAvaliar(View view) {

        Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=com.judsonnunes.calcularmedia");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
        Toast.makeText(getApplicationContext(), "Nos avalie com 5 estrelas <3", Toast.LENGTH_SHORT).show();
    }

    // chamando tela para usuário abrir secretaria virtual da unip

    public void startAssinatura(View view) {

        Intent startAssinatura = new Intent(this, ActivityPagseguro.class);
           startActivity(startAssinatura);

    }

    // tive que criar novo layout e tambem novo activity - activitySiteUnip
    public void startUnip(View view) {

        Intent startUnip1 = new Intent(this, ActivitySiteUnip.class);
        // Chamando interticial
        //launchInter();
        //loadInterstitial();
        // chamando interticial
        startActivity(startUnip1);

    }

    public void startParceiros(View view) {

        Intent startParceiros = new Intent(this, ActivityParceiros.class);
        startActivity(startParceiros);
    }

    //chamar tela activity das duvidas frenquentes
    public void startDuv(View view) {

        Intent startDuv = new Intent(this, ActivityDuvidas.class);
        startActivity(startDuv);
    }

    // chamando playstore com app PRO
    public void startPro(View view) {

        Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=com.judsonnunes.calcularmediaPro");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }

    public void startInstagram(View view) {

        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("http://instagram.com/_u/" + "calcularmediaunip"));
            intent.setPackage("com.instagram.android");
            startActivity(intent);
        }
        catch (android.content.ActivityNotFoundException anfe)
        {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.instagram.com/calcularmediaunip")));
        }

        Toast.makeText(getApplicationContext(), "siga e fique sabendo de todas as novidades!", Toast.LENGTH_SHORT).show();
    }


    // aqui chama a tela para calcular com a nova formula
    // chamando activity gestão
    public void startSite(View view) {

        Uri uri = Uri.parse("https://gfa.unip.br/aluno/");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }


    // configuração de menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);


        return super.onCreateOptionsMenu(menu);

    }
    @Override
    public boolean onOptionsItemSelected (MenuItem item) {

        switch (item.getItemId())
        {


            // menu compartilhar com botão
            case R.id.compartilhar:
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);

                share.putExtra(Intent.EXTRA_TEXT,
                        "Recomendo esse aplicativo pra calcular a média da UNIP Interativa. \nhttps://play.google.com/store/apps/details?id=com.judsonnunes.calcularmedia");

                startActivity(Intent.createChooser(share, "Compartilhar"));
                break;

            // configurando ação menu sobre o app
            case R.id.about:
                Intent intent9=new Intent(getApplicationContext() ,ActivityAbout.class);
                startActivity(intent9);
                break;

        }


        return super.onOptionsItemSelected(item);
    }
    //aqui termina configuração de menu




// Aqui Termina a Terceira Parte do código do Admob

    public void onBackPressed() {

        finish();
        System.exit(0);
    }

    private class SHARED_PREF {
    }
}




